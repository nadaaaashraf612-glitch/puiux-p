"use client";

import { motion } from "framer-motion";
import { useParallax, useMouseParallax } from "../hooks/useReveal";
import { Logo3D } from "../components/Logo3D";
import { PageMeta } from "../components/ui";
import { useLanguage } from "../i18n/LanguageContext";

export function Cover() {
  const bg = useParallax<HTMLDivElement>(0.08);
  const mouse = useMouseParallax(14);
  const { t, dir } = useLanguage();
  const edgeSign = dir === "rtl" ? -1 : 1;

  return (
    <section id="cover" className="relative flex min-h-screen flex-col overflow-hidden bg-black text-white">
      {/* Backdrop — deep studio vignette */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(60% 55% at 70% 45%, rgba(255,255,255,0.10), transparent 70%), radial-gradient(50% 50% at 10% 100%, rgba(255,255,255,0.06), transparent 70%), #000",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40" />

      {/* Fine particle field, medium parallax */}
      <div
        ref={bg.ref}
        className="absolute inset-0 opacity-[0.35]"
        style={{
          transform: `translateY(${bg.offset}px)`,
          backgroundImage:
            "radial-gradient(1px 1px at 20px 20px, rgba(255,255,255,0.5) 1px, transparent 0), radial-gradient(1px 1px at 60px 60px, rgba(255,255,255,0.35) 1px, transparent 0)",
          backgroundSize: "80px 80px",
        }}
      />
      <div className="grain absolute inset-0" />

      {/* Cursor-reactive glow accents */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -end-32 -top-32 h-96 w-96 rounded-full bg-white/10 blur-3xl"
        animate={{ scale: [1, 1.2, 1], opacity: [0.25, 0.45, 0.25] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        style={{ x: mouse.x * -2, y: mouse.y * -2 }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -start-24 bottom-10 h-72 w-72 rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(255,255,255,0.06), transparent 70%)", x: mouse.x * 2, y: mouse.y * 2 }}
        animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.55, 0.3] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="relative z-10 flex flex-1 flex-col px-6 pt-28 sm:px-10 sm:pt-32 lg:px-16">
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-start justify-between gap-6 text-[11px] uppercase tracking-[0.35em] text-white/50 sm:flex-row sm:items-center"
        >
          <span className="inline-flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-white shadow-[0_0_10px_2px_rgba(255,255,255,0.5)]" />
            <span className="font-semibold text-white/80">{t.cover.badge}</span>
          </span>
          <span>{t.cover.tagline}</span>
        </motion.div>

        <div className="relative mt-6 grid flex-1 items-center gap-2 sm:mt-10 lg:grid-cols-[1.05fr_0.95fr] lg:gap-6">
          {/* 3D logo — first on mobile, side-by-side on desktop */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative order-first h-[340px] w-full sm:h-[460px] lg:order-last lg:h-[min(74vh,680px)]"
          >
            <Logo3D className="absolute inset-0" />
          </motion.div>

          <div className="relative">
            <h1
              className="relative select-none font-display font-semibold leading-[0.82] tracking-tight"
              style={{ transform: `translate3d(${mouse.x * -0.6}px, ${mouse.y * -0.6}px, 0)` }}
            >
              {/* ghost outline duplicate */}
              <motion.span
                aria-hidden
                initial={{ opacity: 0, x: 40 * edgeSign }}
                animate={{ opacity: 0.5, x: 0 }}
                transition={{ duration: 1.2, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
                className="pointer-events-none absolute inset-0 block text-[22vw] text-transparent sm:text-[18vw] lg:text-[11vw]"
                style={{ WebkitTextStroke: "1px rgba(255,255,255,0.14)", transform: `translate(${6 * edgeSign}px, 6px)` }}
              >
                PUIUX
              </motion.span>
              <motion.span
                initial={{ opacity: 0, y: 60 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className="shimmer-text relative block text-[22vw] sm:text-[18vw] lg:text-[11vw]"
              >
                PUIUX
              </motion.span>

              {/* corner brackets */}
              <motion.span
                aria-hidden
                className="pointer-events-none absolute -top-4 h-6 w-6 border-t sm:h-8 sm:w-8"
                style={{
                  [dir === "rtl" ? "right" : "left"]: "-0.5rem",
                  borderTopColor: "rgba(255,255,255,0.4)",
                  borderInlineStart: "1px solid rgba(255,255,255,0.4)",
                }}
                animate={{ opacity: [0.3, 0.9, 0.3] }}
                transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
              />
              <motion.span
                aria-hidden
                className="pointer-events-none absolute -bottom-4 h-6 w-6 border-b sm:h-8 sm:w-8"
                style={{
                  [dir === "rtl" ? "left" : "right"]: "-0.5rem",
                  borderBottomColor: "rgba(255,255,255,0.4)",
                  borderInlineEnd: "1px solid rgba(255,255,255,0.4)",
                }}
                animate={{ opacity: [0.3, 0.9, 0.3] }}
                transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut", delay: 1.2 }}
              />
            </h1>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.6 }}
              className="mt-10 grid max-w-xl grid-cols-1 gap-6 border-t border-white/15 pt-8"
            >
              <p className="font-display text-xl font-light leading-snug text-white/85 sm:text-2xl">{t.cover.motto}</p>
              <a
                href="https://www.puiux.com"
                target="_blank"
                rel="noreferrer"
                className="group inline-flex w-fit items-center gap-2 font-display text-sm uppercase tracking-[0.2em] text-white/60 transition hover:text-white"
              >
                <span className="relative">
                  {t.cover.website}
                  <span className="absolute -bottom-1 left-0 h-px w-0 bg-white transition-all duration-500 group-hover:w-full" />
                </span>
              </a>
            </motion.div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="mb-10 mt-8 flex items-center justify-between text-[11px] uppercase tracking-[0.3em] text-white/40"
        >
          <span className="hidden sm:inline">{t.cover.tags}</span>
          <span className="flex items-center gap-3">
            {t.cover.scroll}
            <span className="relative block h-8 w-px overflow-hidden bg-white/15">
              <motion.span
                className="absolute inset-x-0 top-0 h-1/2 bg-white"
                animate={{ y: ["-100%", "200%"] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
              />
            </span>
          </span>
        </motion.div>
      </div>

      <PageMeta index="01" label={t.sectionIndex[0].label} tone="light" />
    </section>
  );
}
