"use client";

import { motion, useMotionValue, useSpring } from "framer-motion";
import { LogoIllustration } from "./LogoIllustration";

export function LuxuryAboutPanel({ monogram = "P" }: { monogram?: string }) {
  const rx = useSpring(useMotionValue(0), { stiffness: 80, damping: 16 });
  const ry = useSpring(useMotionValue(0), { stiffness: 80, damping: 16 });
  const onMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    ry.set(((e.clientX - r.left) / r.width - 0.5) * 14);
    rx.set(-((e.clientY - r.top) / r.height - 0.5) * 14);
  };
  const onLeave = () => {
    rx.set(0);
    ry.set(0);
  };
  const particles = [
    { top: "18%", left: "22%", size: 6, duration: 7, delay: 0 },
    { top: "72%", left: "16%", size: 4, duration: 9, delay: 1.1 },
    { top: "26%", left: "80%", size: 5, duration: 8, delay: 0.4 },
    { top: "64%", left: "78%", size: 7, duration: 10, delay: 1.8 },
    { top: "48%", left: "50%", size: 3, duration: 6.5, delay: 0.8 },
    { top: "85%", left: "55%", size: 4, duration: 8.5, delay: 2.2 },
  ];

  return (
    <div
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      className="relative aspect-[4/5] w-full overflow-hidden rounded-[2rem] bg-[#07060a] shadow-[0_40px_90px_-30px_rgba(0,0,0,0.6)] ring-1 ring-white/10 sm:aspect-square lg:aspect-[4/5]">
      {/* Base luxury gradient wash — deep black */}
      <div
        aria-hidden
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 90% at 20% 0%, rgba(60,60,60,0.3), transparent 55%), radial-gradient(100% 80% at 90% 100%, rgba(40,40,40,0.2), transparent 60%), linear-gradient(160deg, #0a0a0c 0%, #111115 45%, #050406 100%)",
        }}
      />

      {/* Slow-drifting glow blobs (neutral) */}
      <motion.div
        aria-hidden
        className="absolute -left-16 top-10 h-56 w-56 rounded-full bg-white/[0.04] blur-3xl"
        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.85, 0.5] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="absolute -right-10 bottom-0 h-64 w-64 rounded-full bg-white/[0.03] blur-3xl"
        animate={{ scale: [1.1, 0.95, 1.1], opacity: [0.4, 0.75, 0.4] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 0.8 }}
      />

      {/* Faint luxury grid texture */}
      <div
        aria-hidden
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.4) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      />

      {/* Fine grain */}
      <div aria-hidden className="bg-noise absolute inset-0 opacity-[0.12] mix-blend-overlay" />

      {/* Floating particles — white */}
      {particles.map((p, i) => (
        <motion.span
          key={i}
          aria-hidden
          className="absolute rounded-full bg-white/60"
          style={{ top: p.top, left: p.left, width: p.size, height: p.size, boxShadow: "0 0 10px 2px rgba(255,255,255,0.25)" }}
          animate={{ y: [0, -14, 0], opacity: [0.3, 0.9, 0.3] }}
          transition={{ duration: p.duration, repeat: Infinity, ease: "easeInOut", delay: p.delay }}
        />
      ))}

      {/* Centrepiece: orbit emblem + monogram */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          className="relative flex aspect-square w-[82%] items-center justify-center"
          style={{ rotateX: rx, rotateY: ry, transformPerspective: 900 }}
        >
          <LogoIllustration chips={3} className="h-full w-full" />
          <span className="pointer-events-none absolute font-display text-[5.5rem] font-semibold tracking-tight text-white/[0.06] sm:text-[7rem]">
            {monogram}
          </span>
        </motion.div>
      </div>

      {/* Bottom vignette */}
      <div aria-hidden className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/70 to-transparent" />

      {/* Thin edge frame */}
      <div aria-hidden className="pointer-events-none absolute inset-0 rounded-[2rem] ring-1 ring-inset ring-white/10" />
    </div>
  );
}
