"use client";

import { memo, useCallback, useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { SVGLoader } from "three/addons/loaders/SVGLoader.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { LogoIllustration } from "./LogoIllustration";

/** Exact vector geometry of the PUIUX brand mark (unchanged). */
const ICON_PATH =
  "M528 682C400 682 310 610 275 500C258 445 250 410 205 355C175 318 165 295 165 265C165 205 210 165 265 165C325 165 367 220 367 275C367 330 345 355 350 405C355 470 375 520 410 550C445 580 490 590 528 590C566 590 611 580 646 550C681 520 701 470 706 405C711 355 689 330 689 275C689 220 731 165 791 165C846 165 892 205 892 265C892 295 882 318 851 355C806 410 798 445 781 500C746 610 656 682 528 682Z";
const DOT = { cx: 528, cy: 441, rx: 69, ry: 76 };

const easeOutExpo = (x: number) => (x >= 1 ? 1 : 1 - Math.pow(2, -10 * x));

function buildLogoGeometry() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg"><path d="${ICON_PATH}"/></svg>`;
  const data = new SVGLoader().parse(svg);
  const shapes = data.paths[0].toShapes();

  const body = new THREE.ExtrudeGeometry(shapes, {
    depth: 64,
    curveSegments: 40,
    bevelEnabled: true,
    bevelThickness: 18,
    bevelSize: 13,
    bevelSegments: 8,
  });

  const dotShape = new THREE.Shape();
  dotShape.absellipse(DOT.cx, DOT.cy, DOT.rx, DOT.ry, 0, Math.PI * 2, false, 0);
  const dot = new THREE.ExtrudeGeometry(dotShape, {
    depth: 96,
    curveSegments: 48,
    bevelEnabled: true,
    bevelThickness: 16,
    bevelSize: 10,
    bevelSegments: 8,
  });

  // SVG space is y-down → flip both, then centre on the body.
  body.scale(1, -1, 1);
  dot.scale(1, -1, 1);
  body.computeBoundingBox();
  const c = new THREE.Vector3();
  body.boundingBox!.getCenter(c);
  body.translate(-c.x, -c.y, -c.z);
  // dot is a little deeper than the body → protrudes equally on both faces
  dot.translate(-c.x, -c.y, -c.z - 16);
  body.computeVertexNormals();
  dot.computeVertexNormals();

  const width = body.boundingBox!.max.x - body.boundingBox!.min.x;
  return { body, dot, width };
}

function Logo3DScene({ onFail }: { onFail: () => void }) {
  const hostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    } catch {
      onFail();
      return;
    }

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const coarse = window.matchMedia("(pointer: coarse)").matches;

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    const canvas = renderer.domElement;
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    canvas.style.display = "block";
    host.appendChild(canvas);

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;

    const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
    camera.position.set(0, 0, 7);

    // lights – crisp specular accents on top of the studio environment
    const key = new THREE.DirectionalLight(0xffffff, 2.4);
    key.position.set(3, 4, 5);
    const rim = new THREE.DirectionalLight(0xdfe6ff, 2.0);
    rim.position.set(-5, 1, -3);
    const fill = new THREE.PointLight(0xffffff, 18, 12);
    fill.position.set(-2.5, -2, 3.5);
    scene.add(key, rim, fill);

    // ── materials ───────────────────────────────────────────
    const chrome = new THREE.MeshPhysicalMaterial({
      color: 0xd9dbe0,
      metalness: 1,
      roughness: 0.16,
      clearcoat: 1,
      clearcoatRoughness: 0.08,
      envMapIntensity: 1.35,
      side: THREE.DoubleSide,
    });
    const pearl = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      metalness: 0.15,
      roughness: 0.18,
      clearcoat: 1,
      emissive: 0xffffff,
      emissiveIntensity: 0.28,
      envMapIntensity: 1.1,
      side: THREE.DoubleSide,
    });

    const { body, dot, width } = buildLogoGeometry();
    const unit = 2.15 / width; // logo is ~2.15 world-units wide

    const hero = new THREE.Group(); // gets rotation / float
    const logo = new THREE.Group(); // gets scale
    logo.scale.setScalar(unit);
    logo.add(new THREE.Mesh(body, chrome), new THREE.Mesh(dot, pearl));
    hero.add(logo);
    scene.add(hero);

    // ── orbiting mini marks ─────────────────────────────────
    const orbit = new THREE.Group();
    orbit.rotation.set(1.15, 0.2, 0.35);
    const minis: THREE.Group[] = [];
    const MINI = 5;
    for (let i = 0; i < MINI; i++) {
      const m = new THREE.Group();
      const s = unit * 0.1;
      const inner = new THREE.Group();
      inner.scale.setScalar(s);
      inner.add(new THREE.Mesh(body, chrome), new THREE.Mesh(dot, pearl));
      m.add(inner);
      orbit.add(m);
      minis.push(m);
    }
    scene.add(orbit);

    // ── thin rings ──────────────────────────────────────────
    const ringMat = (o: number) => new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: o });
    const ring1 = new THREE.Mesh(new THREE.TorusGeometry(1.72, 0.0045, 8, 220), ringMat(0.38));
    ring1.rotation.set(1.15, 0.2, 0.35);
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(2.05, 0.003, 8, 240), ringMat(0.16));
    ring2.rotation.set(0.5, -0.6, 0.1);
    const ring3 = new THREE.Mesh(new THREE.TorusGeometry(1.38, 0.003, 8, 200), ringMat(0.2));
    ring3.rotation.set(1.9, 0.9, -0.3);
    scene.add(ring1, ring2, ring3);

    // ── dust / particles ────────────────────────────────────
    const N = 220;
    const pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const r = 1.6 + Math.random() * 1.7;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      pos[i * 3] = r * Math.sin(ph) * Math.cos(th);
      pos[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th) * 0.8;
      pos[i * 3 + 2] = r * Math.cos(ph);
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    const pMat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.022,
      transparent: true,
      opacity: 0.7,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      sizeAttenuation: true,
    });
    const dust = new THREE.Points(pGeo, pMat);
    scene.add(dust);

    // ── sizing ──────────────────────────────────────────────
    const resize = () => {
      const w = host.clientWidth || 1;
      const h = host.clientHeight || 1;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      // keep the whole composition in frame on narrow containers
      const fitW = 4.9 / camera.aspect;
      const needed = Math.max(4.1, fitW);
      camera.position.z = (needed / 2) / Math.tan((camera.fov * Math.PI) / 360);
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(host);

    // ── pointer ─────────────────────────────────────────────
    const target = { x: 0, y: 0 };
    const cur = { x: 0, y: 0 };
    const onMove = (e: PointerEvent) => {
      target.x = (e.clientX / window.innerWidth) * 2 - 1;
      target.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    if (!coarse && !reduced) window.addEventListener("pointermove", onMove, { passive: true });

    // ── visibility (pause when off-screen) ──────────────────
    let visible = true;
    const io = new IntersectionObserver(([en]) => (visible = en.isIntersecting), { threshold: 0 });
    io.observe(host);

    // ── loop ────────────────────────────────────────────────
    const clock = new THREE.Clock();
    let raf = 0;
    let t = reduced ? 3 : 0;
    const render = () => {
      raf = requestAnimationFrame(render);
      if (!visible) {
        clock.getDelta();
        return;
      }
      const dt = Math.min(clock.getDelta(), 0.05);
      t += reduced ? 0 : dt;

      cur.x += (target.x - cur.x) * 0.06;
      cur.y += (target.y - cur.y) * 0.06;

      // intro: spin-in with exponential ease
      const intro = easeOutExpo(Math.min(t / 2.6, 1));
      const spinIn = (1 - intro) * Math.PI * 3;

      hero.rotation.y = t * 0.55 + spinIn + cur.x * 0.45;
      hero.rotation.x = Math.sin(t * 0.7) * 0.12 + cur.y * 0.28;
      hero.rotation.z = Math.sin(t * 0.5) * 0.04;
      hero.position.y = Math.sin(t * 1.1) * 0.07;
      hero.scale.setScalar(0.55 + intro * 0.45);

      orbit.rotation.y = 0.2 + cur.x * 0.12;
      orbit.rotation.x = 1.15 + cur.y * 0.1;
      minis.forEach((m, i) => {
        const a = t * 0.5 + (i / MINI) * Math.PI * 2;
        m.position.set(Math.cos(a) * 1.72 * intro, Math.sin(a) * 1.72 * intro, 0);
        m.rotation.set(t * 0.8 + i, t * 1.1 + i * 0.6, 0);
      });
      ring1.rotation.z = 0.35 + t * 0.05;
      ring2.rotation.z = 0.1 - t * 0.04;
      ring2.rotation.y = -0.6 + Math.sin(t * 0.3) * 0.15;
      ring3.rotation.x = 1.9 + Math.sin(t * 0.4) * 0.2;
      ring3.rotation.z = -0.3 + t * 0.08;
      dust.rotation.y = t * 0.04 + cur.x * 0.1;
      dust.rotation.x = cur.y * 0.06;
      pMat.opacity = 0.55 + Math.sin(t * 1.4) * 0.15;

      // light sweep for a living specular highlight
      key.position.x = Math.cos(t * 0.6) * 4;
      key.position.y = 3 + Math.sin(t * 0.45) * 1.2;

      renderer.render(scene, camera);
    };
    render();

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      window.removeEventListener("pointermove", onMove);
      body.dispose();
      dot.dispose();
      chrome.dispose();
      pearl.dispose();
      pGeo.dispose();
      pMat.dispose();
      [ring1, ring2, ring3].forEach((r) => {
        r.geometry.dispose();
        (r.material as THREE.Material).dispose();
      });
      envTex.dispose();
      pmrem.dispose();
      renderer.dispose();
      if (canvas.parentNode === host) host.removeChild(canvas);
    };
  }, [onFail]);

  return <div ref={hostRef} className="absolute inset-0" />;
}

/**
 * Hero illustration: the PUIUX mark as a polished chrome 3D object that
 * spins in, rotates continuously, reacts to the cursor and is orbited by
 * miniature marks and thin light rings. Falls back to the SVG illustration
 * when WebGL isn't available.
 */
function Logo3DBase({ className }: { className?: string }) {
  const [failed, setFailed] = useState(false);
  const onFail = useCallback(() => setFailed(true), []);

  return (
    <div className={className} aria-hidden>
      <div className="relative h-full w-full">
        {/* soft studio glow + ground reflection behind the object */}
        <div
          className="pointer-events-none absolute inset-[6%] rounded-full"
          style={{
            background:
              "radial-gradient(circle at 50% 46%, rgba(255,255,255,0.20) 0%, rgba(255,255,255,0.07) 36%, transparent 68%)",
          }}
        />
        <div
          className="pointer-events-none absolute inset-x-[18%] bottom-[7%] h-[9%] rounded-[50%] blur-xl"
          style={{ background: "radial-gradient(ellipse, rgba(255,255,255,0.28), transparent 70%)" }}
        />
        {failed ? <LogoIllustration chips={2} className="absolute inset-0" /> : <Logo3DScene onFail={onFail} />}
      </div>
    </div>
  );
}

export const Logo3D = memo(Logo3DBase);
